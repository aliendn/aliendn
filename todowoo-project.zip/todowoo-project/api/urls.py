from django.urls import path
from .views import TodoCompletedList, TodoRetrieveUpdateDestroy, TodoComplete

urlpatterns = [
    path('todos', TodoCompletedList.as_view()),
    path('todos/<int:pk>', TodoComplete.as_view()),
    path('todos/completed', TodoCompletedList.as_view()),


]