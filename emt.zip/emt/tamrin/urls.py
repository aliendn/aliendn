from django.contrib import admin
from django.urls import path, include
# from django.urls.base import reverse
from django.conf import settings
from django.conf.urls.static import static
from .views import home



urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('file_manage.urls', namespace='files')),
    path('', include('user.urls', namespace='users')),
    path('', home, name='home')
]



if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
