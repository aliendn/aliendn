from django.urls import path
from .views import loginuser, logout

app_name = 'user'


urlpatterns = [
    path('login/', loginuser, name='login'),
    path('logout/', logout, name="logout")
]
