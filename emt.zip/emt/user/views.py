from django.shortcuts import render, redirect
from .forms import LoginForm
from django.contrib.auth import authenticate, logout as _logout, login as _login

def loginuser(request):
    login_form = LoginForm(request.POST or None)
    if request.method == "POST":
        if login_form.is_valid():
            user_name = login_form.cleaned_data.get('username')
            password = login_form.cleaned_data.get('password')
            user = authenticate(request, username=user_name, password=password)
            if user is not None:
                _login(request, user)
                return redirect('/')
            else:
                login_form.add_error('username', 'کاربری با مشخصات وارد شده یافت نشد')
    else:
        context = {
            'login_form': login_form
        }
        return render(request, 'user/login.html', context)


def logout(request):
    _logout(request)
    return redirect('/')