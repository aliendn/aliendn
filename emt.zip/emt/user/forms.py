from django import forms
from django.contrib.auth.models import User

class LoginForm(forms.Form):
    username = forms.CharField(max_length=255)

    password = forms.CharField(widget=forms.PasswordInput())

    def clean_username(self):
        username = self.cleaned_data.get('username')
        exist_user = User.objects.filter(username=username).exists()
        if not exist_user:
            raise forms.ValidationError('hamchin useri nist')
        return username