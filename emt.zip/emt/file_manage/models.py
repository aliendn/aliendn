from django.db import models
from django.contrib.auth.models import User


class Uploader(models.Model):
    name = models.CharField(max_length=255, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    file_upload = models.FileField(upload_to='media/')
    