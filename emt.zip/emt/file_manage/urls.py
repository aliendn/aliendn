from django.urls import path
from .views import showfiles, createfiles

app_name = 'file_manage'


urlpatterns = [
    path('showfiles/', showfiles, name='showfiles'),
    path('createfiles/', createfiles, name='createfiles')
]
