from django.contrib.auth.models import User
from django.http.response import Http404
from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Uploader
from django.views.decorators.http import require_GET, require_http_methods


@login_required(login_url="/login")
def showfiles(request):
    user_username = request.user.username
    user = User.objects.get(username=user_username)
    files = Uploader.objects.all().filter(user=user)

    context = {
        'files' : files,
        'user' : user
    }
    return render(request, 'file_manage/file_list.html', context)

@login_required(login_url="/login")
def createfiles(request):
    user_username = request.user.username
    user = User.objects.get(username=user_username)

    if user is None:
        raise Http404('همچین کاربری وجود ندارد')
    if request.method == "GET":
            return render(request, 'file_manage/file_create.html', {})
    if request.method == "POST":
        type = request.POST.get('type')
        print(type)
        file_upload = request.FILES.get('file')
        print(file_upload)
        uploading_file = Uploader.objects.create(name=type, file_upload=file_upload, user=user)
        
        
        # return redirect('/showfiles')

        return redirect('/')


