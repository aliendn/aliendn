from django import forms

class UploadFileForm(forms.Form):
    type = forms.CharField(max_length=50)
    file = forms.FileField()